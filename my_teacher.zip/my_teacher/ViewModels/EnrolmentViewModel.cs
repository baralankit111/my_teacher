using my_school.Models;

namespace my_school.ViewModels;

public class JoinedEnrolment : EnrolmentModel
{
    public string StudentName { get; set; }
    public string CourseTitle { get; set; }
}

public class EnrolmentViewModel
{
    public List<StudentModel> Students { get; set; }
    public List<CourseModel> Courses { get; set; }
    public List<JoinedEnrolment> Enrolments { get; set; }
}