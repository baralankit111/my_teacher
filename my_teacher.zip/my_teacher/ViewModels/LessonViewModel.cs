using my_school.Models;

namespace my_school.ViewModels;

public class LessonViewModel
{
    public List<LessonModel> Lessons { get; set; }
    public List<CourseModel> Courses { get; set; }
}