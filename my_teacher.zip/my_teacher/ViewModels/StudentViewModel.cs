using my_school.Models;

namespace my_school.ViewModels;

public class StudentViewModel
{
    public List<StudentModel> Students { get; set; }
    public List<CountryModel> Countries { get; set; }
}