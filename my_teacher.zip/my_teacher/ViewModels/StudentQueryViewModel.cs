using my_school.Models;

namespace my_school.ViewModels;

public class StudentQueryViewModel
{
    public List<StudentQueryModel> StudentQueries { get; set; }
    public List<StudentModel> Students { get; set; }
    public List<EnrolmentModel> Enrolments { get; set; }
    public List<CourseModel> Courses { get; set; }
}