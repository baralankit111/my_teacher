using my_school.Models;

namespace my_school.ViewModels;

public class JoinedCourseInstructorModel : CourseInstructorModel
{
    public string CourseTitle { get; set; }
    public string InstructorName { get; set; }
}

public class CourseInstructorViewModel
{
    public List<CourseModel> Courses { get; set; }
    public List<JoinedCourseInstructorModel> CourseInstructors { get; set; }
    public List<InstructorModel> Instructors { get; set; }
}