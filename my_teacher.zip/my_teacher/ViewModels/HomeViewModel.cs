using my_school.Models;

namespace my_school.ViewModels;

public class HomeViewModel
{
    public int CourseCount { get; set; }
    public int StudentCount { get; set; }
    public int InstructorCount { get; set; }

    public List<CourseModel> MonthlyTopCourses { get; set; }
}