using my_school.Models;
using my_school.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;

namespace my_school.Controllers;

public class FeedbackController : Controller
{
    public IActionResult Index(string searchQuery, string sortBy, string sortOrder = "ASC")
    {
        FeedbackViewModel viewModel = new FeedbackViewModel()
        {
            Feedbacks = new List<FeedbackModel>(),
            Students = new List<StudentModel>(),
            StudentQueries = new List<StudentQueryModel>(),
            Instructors = new List<InstructorModel>(),
            CourseInstructors = new List<CourseInstructorModel>(),
            Enrolments = new List<EnrolmentModel>(),
            Courses = new List<CourseModel>()
        };

        string queryString;
        using OracleConnection connection = new OracleConnection(DbManager.ConnectionString);
        connection.Open();

        // Feedback
        queryString = "SELECT * FROM FEEDBACK";

        if (!string.IsNullOrEmpty(searchQuery))
        {
            queryString += $" WHERE UPPER(FEEDBACK) LIKE UPPER('%{searchQuery}%')";
        }

        if (!string.IsNullOrEmpty(sortBy))
        {
            queryString += $" ORDER BY {sortBy} {sortOrder}";
        }
        else
        {
            queryString += $" ORDER BY FEEDBACK {sortOrder}";
        }

        OracleCommand feedbackCommand = new OracleCommand(queryString, connection);
        OracleDataReader feedbackReader = feedbackCommand.ExecuteReader();
        while (feedbackReader.Read())
        {
            FeedbackModel feedback = new FeedbackModel();
            feedback.FeedbackId = feedbackReader.GetString(0);
            feedback.CourseInstructorId = feedbackReader.GetString(1);
            feedback.StudentQueryId = feedbackReader.GetString(2);
            feedback.FeedbackText = feedbackReader.GetString(3);
            viewModel.Feedbacks.Add(feedback);
        }

        feedbackReader.Dispose();

        // Students
        queryString = "SELECT * FROM STUDENT";

        OracleCommand studentCommand = new OracleCommand(queryString, connection);
        OracleDataReader studentReader = studentCommand.ExecuteReader();
        while (studentReader.Read())
        {
            StudentModel student = new StudentModel();
            student.StudentId = studentReader.GetString(0);
            student.StudentName = studentReader.GetString(1);
            student.CountryId = studentReader.GetString(2);
            student.StudentEmail = studentReader.GetString(3);
            student.StudentContact = studentReader.GetString(4);
            student.StudentDob = studentReader.GetDateTime(5);
            viewModel.Students.Add(student);
        }

        studentReader.Dispose();

        // StudentQuery
        queryString = "SELECT * FROM STUDENTQUERY";

        OracleCommand studentQueryCommand = new OracleCommand(queryString, connection);
        OracleDataReader studentQueryReader = studentQueryCommand.ExecuteReader();
        while (studentQueryReader.Read())
        {
            StudentQueryModel studentQuery = new StudentQueryModel();
            studentQuery.StudentQueryId = studentQueryReader.GetString(0);
            studentQuery.EnrolmentId = studentQueryReader.GetString(1);
            studentQuery.Question = studentQueryReader.GetString(2);
            viewModel.StudentQueries.Add(studentQuery);
        }

        studentQueryReader.Dispose();

        // Instructor
        queryString = "SELECT * FROM INSTRUCTOR";

        OracleCommand instructorCommand = new OracleCommand(queryString, connection);
        OracleDataReader instructorReader = instructorCommand.ExecuteReader();
        while (instructorReader.Read())
        {
            InstructorModel instructor = new InstructorModel();
            instructor.InstructorId = instructorReader.GetString(0);
            instructor.InstructorName = instructorReader.GetString(1);
            instructor.InstructorEmail = instructorReader.GetString(2);
            viewModel.Instructors.Add(instructor);
        }

        instructorReader.Dispose();

        // CourseInstructor
        queryString = "SELECT * FROM COURSEINSTRUCTOR";

        OracleCommand courseInstructorCommand = new OracleCommand(queryString, connection);
        OracleDataReader courseInstructorReader = courseInstructorCommand.ExecuteReader();
        while (courseInstructorReader.Read())
        {
            CourseInstructorModel courseInstructor = new CourseInstructorModel();
            courseInstructor.CourseInstructorId = courseInstructorReader.GetString(0);
            courseInstructor.InstructorId = courseInstructorReader.GetString(1);
            courseInstructor.CourseId = courseInstructorReader.GetString(2);
            viewModel.CourseInstructors.Add(courseInstructor);
        }

        courseInstructorReader.Dispose();

        // Enrolment
        queryString = "SELECT * FROM ENROLMENT";

        OracleCommand enrolmentCommand = new OracleCommand(queryString, connection);
        OracleDataReader enrolmentReader = enrolmentCommand.ExecuteReader();
        while (enrolmentReader.Read())
        {
            EnrolmentModel enrolment = new EnrolmentModel();
            enrolment.EnrolmentId = enrolmentReader.GetString(0);
            enrolment.StudentId = enrolmentReader.GetString(1);
            enrolment.CourseId = enrolmentReader.GetString(2);
            enrolment.EnrolmentDate = enrolmentReader.GetDateTime(3);
            viewModel.Enrolments.Add(enrolment);
        }

        enrolmentReader.Dispose();

        // Course
        queryString = "SELECT * FROM COURSE";

        OracleCommand courseCommand = new OracleCommand(queryString, connection);
        OracleDataReader courseReader = courseCommand.ExecuteReader();
        while (courseReader.Read())
        {
            CourseModel course = new CourseModel();
            course.CourseId = courseReader.GetString(0);
            course.CourseTitle = courseReader.GetString(1);
            course.CourseDescription = courseReader.GetString(2);
            viewModel.Courses.Add(course);
        }

        courseReader.Dispose();

        return View(viewModel);
    }

    [HttpPost]
    public IActionResult Create(FeedbackModel feedback)
    {
        feedback.FeedbackId = Guid.NewGuid().ToString();

        Console.WriteLine(feedback.FeedbackId);
        Console.WriteLine(feedback.CourseInstructorId);
        Console.WriteLine(feedback.StudentQueryId);
        Console.WriteLine(feedback.FeedbackText);

        string queryString =
            $"INSERT INTO FEEDBACK (FEEDBACK_ID, COURSE_INSTRUCTOR_ID, STUDENT_QUERY_ID, FEEDBACK) VALUES ('{feedback.FeedbackId}', '{feedback.CourseInstructorId}', '{feedback.StudentQueryId}', '{feedback.FeedbackText}')";

        DbManager.Execute(queryString);

        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Edit(FeedbackModel feedback)
    {
        DbManager.Execute(
            $"UPDATE FEEDBACK SET COURSE_INSTRUCTOR_ID = '{feedback.CourseInstructorId}', STUDENT_QUERY_ID = '{feedback.StudentQueryId}', FEEDBACK = '{feedback.FeedbackText}' WHERE FEEDBACK_ID = '{feedback.FeedbackId}'");

        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Delete(string id)
    {
        DbManager.Execute($"DELETE FROM FEEDBACK WHERE FEEDBACK_ID = '{id}'");
        return RedirectToAction("Index");
    }
}