using my_school.Models;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;

namespace my_school.Controllers
{
    public class CountryController : Controller
    {
        public ActionResult Index(string searchQuery, string sortBy, string sortOrder = "ASC")
        {
            string queryString = "SELECT * FROM COUNTRY";
            if (!string.IsNullOrEmpty(searchQuery))
            {
                queryString += $" WHERE UPPER(COUNTRY_NAME) LIKE UPPER('%{searchQuery}%')";
            }

            if (!string.IsNullOrEmpty(sortBy))
            {
                queryString += $" ORDER BY {sortBy} {sortOrder}";
            }
            else
            {
                queryString += $" ORDER BY COUNTRY_NAME {sortOrder}";
            }

            List<CountryModel> countries = new List<CountryModel>();
            using OracleConnection connection = new OracleConnection(DbManager.ConnectionString);
            OracleCommand command = new OracleCommand(queryString, connection);
            command.Connection.Open();

            OracleDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                CountryModel country = new CountryModel();
                country.CountryId = reader.GetString(0);
                country.CountryName = reader.GetString(1);
                country.CountryZipCode = reader.GetInt32(2);
                countries.Add(country);
            }

            reader.Dispose();

            return View(countries);
        }

        [HttpPost]
        public IActionResult Create(CountryModel country)
        {
            country.CountryId = Guid.NewGuid().ToString();

            DbManager.Execute(
                $"INSERT INTO COUNTRY (COUNTRY_ID, COUNTRY_NAME, COUNTRY_ZIPCODE) VALUES ('{country.CountryId}', '{country.CountryName}', '{country.CountryZipCode}')");

            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Edit(CountryModel country)
        {
            DbManager.Execute(
                $"UPDATE COUNTRY SET COUNTRY_NAME = '{country.CountryName}', COUNTRY_ZIPCODE = '{country.CountryZipCode}' WHERE COUNTRY_ID = '{country.CountryId}'");

            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Delete(string id)
        {
            DbManager.Execute($"DELETE FROM COUNTRY WHERE COUNTRY_ID = '{id}'");
            return RedirectToAction("Index");
        }
    }
}