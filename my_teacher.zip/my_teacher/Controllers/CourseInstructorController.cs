using my_school.Models;
using my_school.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;

namespace my_school.Controllers;

public class CourseInstructorController : Controller
{
    public IActionResult Index(string searchQuery)
    {
        string queryString =
            "SELECT ci.COURSE_INSTRUCTOR_ID, c.COURSE_ID, c.COURSE_TITLE, i.INSTRUCTOR_ID, i.INSTRUCTOR_NAME FROM CourseInstructor ci JOIN Course c ON ci.COURSE_ID = c.COURSE_ID JOIN Instructor i ON ci.INSTRUCTOR_ID = i.INSTRUCTOR_ID";


        if (!string.IsNullOrEmpty(searchQuery))
        {
            queryString +=
                $" WHERE UPPER(c.COURSE_TITLE) LIKE UPPER('%{searchQuery}%') OR UPPER(i.INSTRUCTOR_NAME) LIKE UPPER('%{searchQuery}%')";
        }

        CourseInstructorViewModel courseInstructorViewModel = new CourseInstructorViewModel()
        {
            Courses = new List<CourseModel>(),
            Instructors = new List<InstructorModel>(),
            CourseInstructors = new List<JoinedCourseInstructorModel>()
        };


        using OracleConnection connection = new OracleConnection(DbManager.ConnectionString);
        OracleCommand command = new OracleCommand(queryString, connection);
        command.Connection.Open();

        OracleDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
            JoinedCourseInstructorModel courseInstructor = new JoinedCourseInstructorModel();
            courseInstructor.CourseInstructorId = reader.GetString(0);
            courseInstructor.CourseId = reader.GetString(1);
            courseInstructor.CourseTitle = reader.GetString(2);
            courseInstructor.InstructorId = reader.GetString(3);
            courseInstructor.InstructorName = reader.GetString(4);

            courseInstructorViewModel.CourseInstructors.Add(courseInstructor);
        }

        reader.Dispose();

        queryString = "SELECT * FROM COURSE";

        // Get All Courses
        using OracleConnection courseConnection = new OracleConnection(DbManager.ConnectionString);
        OracleCommand courseCommand = new OracleCommand(queryString, courseConnection);
        courseCommand.Connection.Open();

        OracleDataReader courseReader = courseCommand.ExecuteReader();
        while (courseReader.Read())
        {
            CourseModel course = new CourseModel();
            course.CourseId = courseReader.GetString(0);
            course.CourseTitle = courseReader.GetString(1);
            course.CourseDescription = courseReader.GetString(2);

            courseInstructorViewModel.Courses.Add(course);
        }

        courseReader.Dispose();

        queryString = "SELECT * FROM INSTRUCTOR";

        // Get All Instructors
        using OracleConnection insConnection = new OracleConnection(DbManager.ConnectionString);
        OracleCommand insCommand = new OracleCommand(queryString, insConnection);
        insCommand.Connection.Open();

        OracleDataReader insReader = insCommand.ExecuteReader();
        while (insReader.Read())
        {
            InstructorModel instructor = new InstructorModel();
            instructor.InstructorId = insReader.GetString(0);
            instructor.InstructorName = insReader.GetString(1);
            instructor.InstructorEmail = insReader.GetString(2);

            courseInstructorViewModel.Instructors.Add(instructor);
        }

        insReader.Dispose();

        return View(courseInstructorViewModel);
    }

    [HttpPost]
    public IActionResult Create(CourseInstructorModel courseInstructor)
    {
        courseInstructor.CourseInstructorId = Guid.NewGuid().ToString();

        DbManager.Execute(
            $"INSERT INTO COURSEINSTRUCTOR (COURSE_INSTRUCTOR_ID, COURSE_ID, INSTRUCTOR_ID) VALUES ('{courseInstructor.CourseInstructorId}', '{courseInstructor.CourseId}', '{courseInstructor.InstructorId}')");

        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Edit(CourseInstructorModel courseInstructor)
    {
        Console.WriteLine(courseInstructor.CourseInstructorId);
        Console.WriteLine(courseInstructor.InstructorId);
        Console.WriteLine(courseInstructor.CourseId);
        DbManager.Execute(
            $"UPDATE COURSEINSTRUCTOR SET COURSE_ID = '{courseInstructor.CourseId}', INSTRUCTOR_ID = '{courseInstructor.InstructorId}' WHERE COURSE_INSTRUCTOR_ID = '{courseInstructor.CourseInstructorId}'");

        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Delete(string id)
    {
        DbManager.Execute($"DELETE FROM COURSEINSTRUCTOR WHERE COURSE_INSTRUCTOR_ID = '{id}'");
        return RedirectToAction("Index");
    }
}