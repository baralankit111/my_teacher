using System.Diagnostics;
using my_school.Models;
using my_school.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;

namespace my_school.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index(string month = null)
    {
        DashboardViewModel viewModel = new DashboardViewModel()
        {
            TotalEnrolments = 0,
            TotalInstructors = 0,
            TotalStudents = 0,
            TotalCourses = 0,

            TopCourses = new List<TopCourse>(),
            MonthlyEnrolInsights = new List<MonthlyEnrolInsight>()
        };

        using OracleConnection connection = new OracleConnection(DbManager.ConnectionString);
        connection.Open();

        string queryString = "SELECT COUNT(*) FROM ENROLMENT";
        OracleCommand enrolmentCountCommand = new OracleCommand(queryString, connection);
        viewModel.TotalEnrolments = Convert.ToInt32(enrolmentCountCommand.ExecuteScalar());

        queryString = "SELECT COUNT(*) FROM INSTRUCTOR";
        OracleCommand instructorCountCommand = new OracleCommand(queryString, connection);
        viewModel.TotalInstructors = Convert.ToInt32(instructorCountCommand.ExecuteScalar());

        queryString = "SELECT COUNT(*) FROM STUDENT";
        OracleCommand studentCountCommand = new OracleCommand(queryString, connection);
        viewModel.TotalStudents = Convert.ToInt32(studentCountCommand.ExecuteScalar());

        queryString = "SELECT COUNT(*) FROM COURSE";
        OracleCommand courseCountCommand = new OracleCommand(queryString, connection);
        viewModel.TotalCourses = Convert.ToInt32(courseCountCommand.ExecuteScalar());


        // Monthly Top 3 Courses

        if (month != null)
        {
            queryString =
                $"SELECT COURSE_ID, COURSE_TITLE, COURSE_DESCRIPTION, enrol_count FROM (SELECT c.COURSE_ID, c.COURSE_TITLE, c.COURSE_DESCRIPTION, COUNT(*) AS enrol_count FROM ENROLMENT e JOIN COURSE c ON e.COURSE_ID = c.COURSE_ID WHERE TO_CHAR(ENROL_DATE, 'YYYY-MM') = '{month}' GROUP BY c.COURSE_ID, c.COURSE_TITLE, c.COURSE_DESCRIPTION ORDER BY enrol_count DESC) WHERE ROWNUM <= 3";
        }
        else
        {
            queryString =
                "SELECT COURSE_ID, COURSE_TITLE, COURSE_DESCRIPTION, enrol_count FROM (SELECT c.COURSE_ID, c.COURSE_TITLE, c.COURSE_DESCRIPTION, COUNT(*) AS enrol_count FROM ENROLMENT e JOIN COURSE c ON e.COURSE_ID = c.COURSE_ID WHERE TO_CHAR(ENROL_DATE, 'MM') = TO_CHAR(SYSDATE, 'MM') AND TO_CHAR(ENROL_DATE, 'YYYY') = TO_CHAR(SYSDATE, 'YYYY') GROUP BY c.COURSE_ID, c.COURSE_TITLE, c.COURSE_DESCRIPTION ORDER BY enrol_count DESC) WHERE ROWNUM <= 3";
        }


        OracleCommand monthlyTopCoursesCommand = new OracleCommand(queryString, connection);
        OracleDataReader reader = monthlyTopCoursesCommand.ExecuteReader();
        while (reader.Read())
        {
            TopCourse course = new TopCourse();
            course.CourseId = reader.GetString(0);
            course.CourseTitle = reader.GetString(1);
            course.CourseDescription = reader.GetString(2);
            course.EnrolCount = reader.GetInt32(3);
            viewModel.TopCourses.Add(course);
        }

        reader.Dispose();

        // Monthly Enrolment Insight
        queryString =
            "SELECT TO_CHAR(enrol_date, 'MM') AS month_number, TO_CHAR(enrol_date, 'Month') AS month_name, COUNT(*) AS enrol_count FROM enrolment WHERE TO_CHAR(enrol_date, 'YYYY') = TO_CHAR(SYSDATE, 'YYYY') GROUP BY TO_CHAR(enrol_date, 'MM'), TO_CHAR(enrol_date, 'Month') ORDER BY TO_CHAR(enrol_date, 'MM')";
        OracleCommand monthlyEnrolmentInsightCommand = new OracleCommand(queryString, connection);
        OracleDataReader monthlyEnrolmentInsightReader = monthlyEnrolmentInsightCommand.ExecuteReader();
        while (monthlyEnrolmentInsightReader.Read())
        {
            MonthlyEnrolInsight insight = new MonthlyEnrolInsight();
            insight.MonthNumber = monthlyEnrolmentInsightReader.GetString(0);
            insight.MonthName = monthlyEnrolmentInsightReader.GetString(1);
            insight.EnrolCount = monthlyEnrolmentInsightReader.GetInt32(2);
            viewModel.MonthlyEnrolInsights.Add(insight);
        }

        monthlyEnrolmentInsightReader.Dispose();


        return View(viewModel);
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}