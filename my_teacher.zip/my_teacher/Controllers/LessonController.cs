using my_school.Models;
using my_school.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;

namespace my_school.Controllers;

public class LessonController : Controller
{
    public IActionResult Index(string searchQuery, string sortBy, string sortOrder = "ASC")
    {
        string queryString = "SELECT * FROM LESSON";

        if (!string.IsNullOrEmpty(searchQuery))
        {
            queryString += $" WHERE UPPER(LESSON_NUMBER) LIKE UPPER('%{searchQuery}%')";
        }

        if (!string.IsNullOrEmpty(sortBy))
        {
            queryString += $" ORDER BY {sortBy} {sortOrder}";
        }
        else
        {
            queryString += $" ORDER BY LESSON_NUMBER {sortOrder}";
        }

        LessonViewModel viewModel = new LessonViewModel()
        {
            Lessons = new List<LessonModel>(),
            Courses = new List<CourseModel>()
        };

        using OracleConnection connection = new OracleConnection(DbManager.ConnectionString);
        OracleCommand command = new OracleCommand(queryString, connection);
        command.Connection.Open();

        OracleDataReader reader = command.ExecuteReader();
        while (reader.Read())
        {
            LessonModel lesson = new LessonModel();
            lesson.LessonId = reader.GetString(0);
            lesson.LessonNumber = reader.GetInt16(1);
            lesson.CourseId = reader.GetString(2);
            lesson.LessonContent = reader.GetString(3);
            viewModel.Lessons.Add(lesson);
        }

        reader.Dispose();

        queryString = "SELECT * FROM COURSE";

        using OracleConnection newConnection = new OracleConnection(DbManager.ConnectionString);
        OracleCommand commandCourse = new OracleCommand(queryString, newConnection);
        commandCourse.Connection.Open();

        OracleDataReader courseReader = commandCourse.ExecuteReader();
        while (courseReader.Read())
        {
            CourseModel course = new CourseModel();
            course.CourseId = courseReader.GetString(0);
            course.CourseTitle = courseReader.GetString(1);
            course.CourseDescription = courseReader.GetString(2);
            viewModel.Courses.Add(course);
        }

        courseReader.Dispose();

        return View(viewModel);
    }

    [HttpPost]
    public IActionResult Create(LessonModel lesson, IFormFile lessonContent)
    {
        lesson.LessonId = Guid.NewGuid().ToString();

        if (lessonContent != null && lessonContent.Length > 0)
        {
            string uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Images", "lessons");
            if (!Directory.Exists(uploadsFolder))
            {
                Directory.CreateDirectory(uploadsFolder);
            }

            string uniqueFileName = $"{Guid.NewGuid().ToString()}_{Path.GetFileName(lessonContent.FileName)}";
            string imagePath = Path.Combine(uploadsFolder, uniqueFileName);

            using (var stream = new FileStream(imagePath, FileMode.Create))
            {
                lessonContent.CopyTo(stream);
            }

            lesson.LessonContent = $"/Images/lessons/{uniqueFileName}";
        }

        DbManager.Execute(
            $"INSERT INTO LESSON (LESSON_ID, LESSON_NUMBER, COURSE_ID, LESSON_CONTENT) VALUES ('{lesson.LessonId}', '{lesson.LessonNumber}', '{lesson.CourseId}', '{lesson.LessonContent}')");

        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Edit(LessonModel lesson, IFormFile lessonContent)
    {
        if (lessonContent != null && lessonContent.Length > 0)
        {
            string uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Images", "lessons");
            if (!Directory.Exists(uploadsFolder))
            {
                Directory.CreateDirectory(uploadsFolder);
            }

            string uniqueFileName = $"{Guid.NewGuid().ToString()}_{Path.GetFileName(lessonContent.FileName)}";
            string imagePath = Path.Combine(uploadsFolder, uniqueFileName);

            using (var stream = new FileStream(imagePath, FileMode.Create))
            {
                lessonContent.CopyTo(stream);
            }

            lesson.LessonContent = $"/Images/lessons/{uniqueFileName}";
        }


        if (lesson.LessonContent == null)
        {
            DbManager.Execute(
                $"UPDATE LESSON SET LESSON_NUMBER = '{lesson.LessonNumber}', COURSE_ID = '{lesson.CourseId}' WHERE LESSON_ID = '{lesson.LessonId}'");
        }
        else
        {
            DbManager.Execute(
                $"UPDATE LESSON SET LESSON_NUMBER = '{lesson.LessonNumber}', COURSE_ID = '{lesson.CourseId}', LESSON_CONTENT = '{lesson.LessonContent}' WHERE LESSON_ID = '{lesson.LessonId}'");
        }


        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Delete(string id)
    {
        DbManager.Execute($"DELETE FROM LESSON WHERE LESSON_ID = '{id}'");
        return RedirectToAction("Index");
    }
}