using my_school.Models;
using my_school.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;

namespace my_school.Controllers;

public class StudentQueryController : Controller
{
    public IActionResult Index(string searchQuery, string sortBy, string sortOrder = "ASC")
    {
        StudentQueryViewModel viewModel = new StudentQueryViewModel()
        {
            Courses = new List<CourseModel>(),
            Enrolments = new List<EnrolmentModel>(),
            StudentQueries = new List<StudentQueryModel>(),
            Students = new List<StudentModel>()
        };

        string queryString;
        using OracleConnection connection = new OracleConnection(DbManager.ConnectionString);
        connection.Open();

        // Student Query
        queryString = "SELECT * FROM STUDENTQUERY";

        if (!string.IsNullOrEmpty(searchQuery))
        {
            queryString += $" WHERE UPPER(QUESTION) LIKE UPPER('%{searchQuery}%')";
        }

        if (!string.IsNullOrEmpty(sortBy))
        {
            queryString += $" ORDER BY {sortBy} {sortOrder}";
        }
        else
        {
            queryString += $" ORDER BY QUESTION {sortOrder}";
        }


        OracleCommand getStudentQueryCommand = new OracleCommand(queryString, connection);
        OracleDataReader studentQueryReader = getStudentQueryCommand.ExecuteReader();
        while (studentQueryReader.Read())
        {
            StudentQueryModel studentQuery = new StudentQueryModel();
            studentQuery.StudentQueryId = studentQueryReader.GetString(0);
            studentQuery.EnrolmentId = studentQueryReader.GetString(1);
            studentQuery.Question = studentQueryReader.GetString(2);
            viewModel.StudentQueries.Add(studentQuery);
        }

        studentQueryReader.Dispose();

        // Course
        queryString = "SELECT * FROM COURSE";
        OracleCommand getCourseCommand = new OracleCommand(queryString, connection);
        OracleDataReader courseReader = getCourseCommand.ExecuteReader();
        while (courseReader.Read())
        {
            CourseModel course = new CourseModel();
            course.CourseId = courseReader.GetString(0);
            course.CourseTitle = courseReader.GetString(1);
            course.CourseDescription = courseReader.GetString(2);
            viewModel.Courses.Add(course);
        }

        courseReader.Dispose();

        // Enrolment
        queryString = "SELECT * FROM ENROLMENT";
        OracleCommand getEnrolmentCommand = new OracleCommand(queryString, connection);
        OracleDataReader enrolmentReader = getEnrolmentCommand.ExecuteReader();
        while (enrolmentReader.Read())
        {
            EnrolmentModel enrolment = new EnrolmentModel();
            enrolment.EnrolmentId = enrolmentReader.GetString(0);
            enrolment.StudentId = enrolmentReader.GetString(1);
            enrolment.CourseId = enrolmentReader.GetString(2);
            enrolment.EnrolmentDate = enrolmentReader.GetDateTime(3);
            viewModel.Enrolments.Add(enrolment);
        }

        enrolmentReader.Dispose();

        // Student
        queryString = "SELECT * FROM STUDENT";
        OracleCommand getStudentCommand = new OracleCommand(queryString, connection);
        OracleDataReader studentReader = getStudentCommand.ExecuteReader();
        while (studentReader.Read())
        {
            StudentModel student = new StudentModel();
            student.StudentId = studentReader.GetString(0);
            student.StudentName = studentReader.GetString(1);
            student.CountryId = studentReader.GetString(2);
            student.StudentEmail = studentReader.GetString(3);
            student.StudentContact = studentReader.GetString(4);
            student.StudentDob = studentReader.GetDateTime(5);
            viewModel.Students.Add(student);
        }

        studentReader.Dispose();

        return View(viewModel);
    }


    [HttpPost]
    public IActionResult Create(StudentQueryModel studentQuery)
    {
        studentQuery.StudentQueryId = Guid.NewGuid().ToString();

        string queryString =
            $"INSERT INTO STUDENTQUERY (STUDENT_QUERY_ID, ENROLMENT_ID, QUESTION) VALUES ('{studentQuery.StudentQueryId}', '{studentQuery.EnrolmentId}', '{studentQuery.Question}')";

        DbManager.Execute(queryString);

        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Edit(StudentQueryModel studentQuery)
    {
        DbManager.Execute(
            $"UPDATE STUDENTQUERY SET ENROLMENT_ID = '{studentQuery.EnrolmentId}', QUESTION = '{studentQuery.Question}' WHERE STUDENT_QUERY_ID = '{studentQuery.StudentQueryId}'");

        return RedirectToAction("Index");
    }

    [HttpPost]
    public IActionResult Delete(string id)
    {
        DbManager.Execute($"DELETE FROM STUDENTQUERY WHERE STUDENT_QUERY_ID = '{id}'");
        return RedirectToAction("Index");
    }
}