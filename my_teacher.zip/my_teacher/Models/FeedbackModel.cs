using System.ComponentModel.DataAnnotations;

namespace my_school.Models;

public class FeedbackModel
{
    [Key]
    public string FeedbackId { get; set; }
    
    [Required]
    public string CourseInstructorId { get; set; }
    
    [Required]
    public string StudentQueryId { get; set; }
    
    [Required]
    public string FeedbackText { get; set; }
}