using System.ComponentModel.DataAnnotations;

namespace my_school.Models;

public class InstructorModel
{
    [Key]
    public string InstructorId { get; set; }
    
    [Required]
    public string InstructorName { get; set; }
    
    [Required]
    public string InstructorEmail { get; set; }
}