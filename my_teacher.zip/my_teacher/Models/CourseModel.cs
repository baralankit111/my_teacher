using System.ComponentModel.DataAnnotations;

namespace my_school.Models;

public class CourseModel
{
    [Key]
    public string CourseId { get; set; }

    [Required]
    public string CourseTitle { get; set; }

    [Required]
    public string CourseDescription { get; set; }
}