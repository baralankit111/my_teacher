using System.ComponentModel.DataAnnotations;

namespace my_school.Models;

public class CourseInstructorModel
{
    [Key] public string CourseInstructorId { get; set; }

    [Required] public string InstructorId { get; set; }

    [Required] public string CourseId { get; set; }
}