using System.ComponentModel.DataAnnotations;

namespace my_school.Models;

public class StudentQueryModel
{
    [Key] public string StudentQueryId { get; set; }

    [Required] public string EnrolmentId { get; set; }

    [Required] public string Question { get; set; }
}