using System.ComponentModel.DataAnnotations;

namespace my_school.Models;

public class StudentModel
{
    [Key] public string StudentId { get; set; }

    [Required] public string StudentName { get; set; }

    [Required] public string CountryId { get; set; }

    [Required] public string StudentEmail { get; set; }

    [Required] public string StudentContact { get; set; }

    [Required] public DateTime StudentDob { get; set; }
}