using System.ComponentModel.DataAnnotations;

namespace my_school.Models;

public class EnrolmentModel
{
    [Key] public string EnrolmentId { get; set; }

    [Required] public string StudentId { get; set; }

    [Required] public string CourseId { get; set; }

    [Required] public DateTime EnrolmentDate { get; set; }
}