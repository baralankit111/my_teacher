using System.ComponentModel.DataAnnotations;

namespace my_school.Models;

public class CountryModel
{
    [Key] public string CountryId { get; set; }

    [Required] public string CountryName { get; set; }

    [Required] public Int32 CountryZipCode { get; set; }
}